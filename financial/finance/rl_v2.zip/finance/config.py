# ================================================================================================================
# Configuration file for Optimal Liquidation Project
# ================================================================================================================

# ------------------------------------------------ Financial Parameters --------------------------------------------------- #

# Market parameters
ANNUAL_VOLAT = 0.12                                # Annual volatility in stock price
BID_ASK_SP = 1 / 8                                 # Bid-ask spread
DAILY_TRADE_VOL = 5e6                              # Average Daily trading volume  
TRAD_DAYS = 250                                    # Number of trading days in a year
DAILY_VOLAT = ANNUAL_VOLAT / (TRAD_DAYS ** 0.5)   # Daily volatility in stock price

# ----------------------------- Parameters for the Almgren and Chriss Optimal Execution Model ----------------------------- #

# Trading parameters
TOTAL_SHARES = 1000000                                               # Total number of shares to sell
STARTING_PRICE = 50                                                  # Starting price per share
LLAMBDA = 1e-6                                                       # Trader's risk aversion
LIQUIDATION_TIME = 60                                                # How many days to sell all the shares. 
NUM_N = 60                                                           # Number of trades

# Derived parameters
EPSILON = BID_ASK_SP / 2                                             # Fixed Cost of Selling.
SINGLE_STEP_VARIANCE = (DAILY_VOLAT * STARTING_PRICE) ** 2           # Calculate single step variance
ETA = BID_ASK_SP / (0.01 * DAILY_TRADE_VOL)                         # Price Impact for Each 1% of Daily Volume Traded
GAMMA = BID_ASK_SP / (0.1 * DAILY_TRADE_VOL)                        # Permanent Impact Constant

# ------------------------------------------------ DDPG Hyperparameters --------------------------------------------------- #

# Network architecture
ACTOR_FC1_UNITS = 24                # Number of nodes in first hidden layer of Actor
ACTOR_FC2_UNITS = 48                # Number of nodes in second hidden layer of Actor
CRITIC_FCS1_UNITS = 24              # Number of nodes in first hidden layer of Critic
CRITIC_FC2_UNITS = 48               # Number of nodes in second hidden layer of Critic

# Training parameters
BUFFER_SIZE = int(1e4)              # replay buffer size
BATCH_SIZE = 128                    # minibatch size
GAMMA = 0.99                        # discount factor
TAU = 1e-3                          # for soft update of target parameters
LR_ACTOR = 1e-4                     # learning rate of the actor 
LR_CRITIC = 1e-3                    # learning rate of the critic
WEIGHT_DECAY = 0                    # L2 weight decay

# Noise parameters (Ornstein-Uhlenbeck)
OU_MU = 0.0                         # Mean of the noise
OU_THETA = 0.15                     # How fast the noise reverts to mean
OU_SIGMA = 0.2                      # Volatility of the noise

# Training settings
NUM_EPISODES = 1000                 # Number of training episodes
MAX_TIMESTEPS = 60                  # Maximum timesteps per episode (should match NUM_N)
RANDOM_SEED = 42                    # Random seed for reproducibility

# -------------------------------------------- Environment Configuration -------------------------------------------- #

# Environment type settings
USE_GBM = False                     # Use Geometric Brownian Motion instead of Arithmetic
TRANSACTION_FEE = 0.0               # Transaction fee as percentage of trade value
ADD_MARKET_NOISE = True             # Add additional market noise beyond AC model

# State space configuration
STATE_HISTORY_LENGTH = 6            # Number of historical price returns to include in state
NORMALIZE_STATE = True              # Whether to normalize state values

# ------------------------------------------------ Logging and Output ------------------------------------------------- #

# Results directory
RESULTS_DIR = "analysis/results/"
PLOTS_DIR = "analysis/plots/"

# Logging settings
LOG_INTERVAL = 100                  # Print progress every N episodes
SAVE_INTERVAL = 500                 # Save model every N episodes
PLOT_RESULTS = True                 # Whether to generate plots

# Model saving
SAVE_MODELS = True                  # Whether to save trained models
MODEL_SAVE_PATH = "analysis/results/models/"

# -------------------------------------------- Benchmark Configuration -------------------------------------------- #

# Almgren-Chriss benchmark settings
AC_LAMBDA_RANGE = [1e-8, 1e-6, 1e-4, 1e-2]  # Range of lambda values for efficient frontier
AC_NUM_POINTS = 50                            # Number of points on efficient frontier
AC_RANDOM_SEED = 42                           # Random seed for AC simulations

# ================================================================================================================ 