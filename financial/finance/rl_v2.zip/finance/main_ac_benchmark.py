#!/usr/bin/env python3
"""
Almgren-Chriss Benchmark Script
===============================

This script runs the Almgren-Chriss analytical benchmark for optimal liquidation,
calculates the optimal strategy for given risk aversion parameters, and saves
the results to CSV files for comparison with RL agents.

Usage:
    python main_ac_benchmark.py
"""

import numpy as np
import pandas as pd
import os
import sys
from datetime import datetime

# Import project modules
from envs.base_env import MarketEnvironment
import utils
import config

def run_ac_benchmark(lambda_val=config.LLAMBDA, num_simulations=100, save_results=True):
    """
    Run the Almgren-Chriss benchmark for a given risk aversion parameter.
    
    Args:
        lambda_val (float): Risk aversion parameter
        num_simulations (int): Number of simulation runs for averaging
        save_results (bool): Whether to save results to CSV
        
    Returns:
        dict: Dictionary containing benchmark results
    """
    print(f"Running Almgren-Chriss Benchmark with λ = {lambda_val}")
    print(f"Number of simulations: {num_simulations}")
    print("-" * 50)
    
    # Initialize environment with the specified lambda
    env = MarketEnvironment(randomSeed=config.AC_RANDOM_SEED, lambd=lambda_val)
    
    # Get the optimal trade list from AC model
    optimal_trades = env.get_trade_list()
    
    # Calculate theoretical values
    theoretical_expected_shortfall = env.get_AC_expected_shortfall(config.TOTAL_SHARES)
    theoretical_variance = env.get_AC_variance(config.TOTAL_SHARES)
    theoretical_utility = env.compute_AC_utility(config.TOTAL_SHARES)
    
    print(f"Theoretical Expected Shortfall: ${theoretical_expected_shortfall:.2f}")
    print(f"Theoretical Variance: ${theoretical_variance:.2f}")
    print(f"Theoretical Utility: ${theoretical_utility:.2f}")
    print()
    
    # Run simulations with the optimal strategy
    implementation_shortfalls = []
    total_captures = []
    
    for sim in range(num_simulations):
        # Reset environment for each simulation
        env.reset(seed=sim, lamb=lambda_val)
        env.start_transactions()
        
        total_capture = 0
        
        # Execute the optimal trade list
        for trade_idx, shares_to_sell in enumerate(optimal_trades):
            # Convert shares to action (percentage of remaining shares)
            if env.shares_remaining > 0:
                action = shares_to_sell / env.shares_remaining
                action = np.clip(action, 0, 1)  # Ensure action is in valid range
            else:
                action = 0
            
            # Take the action
            state, reward, done, info = env.step(action)
            
            if done:
                # Check if implementation_shortfall exists in info (it should for completed episodes)
                if hasattr(info, 'implementation_shortfall'):
                    implementation_shortfalls.append(getattr(info, 'implementation_shortfall'))
                else:
                    # Fallback: calculate implementation shortfall manually
                    implementation_shortfalls.append(env.total_shares * env.startingPrice - env.totalCapture)
                total_captures.append(env.totalCapture)
                break
    
    # Calculate statistics
    mean_shortfall = np.mean(implementation_shortfalls)
    std_shortfall = np.std(implementation_shortfalls)
    mean_capture = np.mean(total_captures)
    
    print(f"Simulation Results ({num_simulations} runs):")
    print(f"Mean Implementation Shortfall: ${mean_shortfall:.2f}")
    print(f"Std Implementation Shortfall: ${std_shortfall:.2f}")
    print(f"Mean Total Capture: ${mean_capture:.2f}")
    print()
    
    # Prepare results dictionary
    results = {
        'lambda': lambda_val,
        'num_simulations': num_simulations,
        'theoretical_expected_shortfall': theoretical_expected_shortfall,
        'theoretical_variance': theoretical_variance,
        'theoretical_utility': theoretical_utility,
        'mean_implementation_shortfall': mean_shortfall,
        'std_implementation_shortfall': std_shortfall,
        'mean_total_capture': mean_capture,
        'optimal_trades': optimal_trades.tolist(),
        'individual_shortfalls': implementation_shortfalls,
        'timestamp': datetime.now().isoformat()
    }
    
    if save_results:
        save_benchmark_results(results)
    
    return results

def save_benchmark_results(results):
    """
    Save benchmark results to CSV files.
    
    Args:
        results (dict): Results dictionary from run_ac_benchmark
    """
    # Create results directory if it doesn't exist
    os.makedirs(config.RESULTS_DIR, exist_ok=True)
    
    # Save summary results
    summary_file = os.path.join(config.RESULTS_DIR, 'ac_benchmark_summary.csv')
    summary_data = {
        'lambda': [results['lambda']],
        'num_simulations': [results['num_simulations']],
        'theoretical_expected_shortfall': [results['theoretical_expected_shortfall']],
        'theoretical_variance': [results['theoretical_variance']],
        'theoretical_utility': [results['theoretical_utility']],
        'mean_implementation_shortfall': [results['mean_implementation_shortfall']],
        'std_implementation_shortfall': [results['std_implementation_shortfall']],
        'mean_total_capture': [results['mean_total_capture']],
        'timestamp': [results['timestamp']]
    }
    
    summary_df = pd.DataFrame(summary_data)
    
    # Append to existing file or create new one
    if os.path.exists(summary_file):
        existing_df = pd.read_csv(summary_file)
        summary_df = pd.concat([existing_df, summary_df], ignore_index=True)
    
    summary_df.to_csv(summary_file, index=False)
    print(f"Summary results saved to: {summary_file}")
    
    # Save optimal trade list
    trades_file = os.path.join(config.RESULTS_DIR, f'ac_optimal_trades_lambda_{results["lambda"]:.2e}.csv')
    trades_df = pd.DataFrame({
        'trade_step': range(1, len(results['optimal_trades']) + 1),
        'shares_to_sell': results['optimal_trades']
    })
    trades_df.to_csv(trades_file, index=False)
    print(f"Optimal trades saved to: {trades_file}")
    
    # Save individual simulation results
    sims_file = os.path.join(config.RESULTS_DIR, f'ac_simulations_lambda_{results["lambda"]:.2e}.csv')
    sims_df = pd.DataFrame({
        'simulation': range(1, len(results['individual_shortfalls']) + 1),
        'implementation_shortfall': results['individual_shortfalls']
    })
    sims_df.to_csv(sims_file, index=False)
    print(f"Individual simulation results saved to: {sims_file}")

def generate_efficient_frontier(lambda_range=None, num_points=50, save_results=True):
    """
    Generate the efficient frontier by running AC benchmark for multiple lambda values.
    
    Args:
        lambda_range (list): List of [min_lambda, max_lambda] for the range
        num_points (int): Number of points on the efficient frontier
        save_results (bool): Whether to save results to CSV
        
    Returns:
        pd.DataFrame: DataFrame containing efficient frontier data
    """
    if lambda_range is None:
        lambda_range = [1e-8, 1e-2]
    
    print(f"Generating Efficient Frontier with {num_points} points")
    print(f"Lambda range: {lambda_range[0]:.2e} to {lambda_range[1]:.2e}")
    print("-" * 50)
    
    # Generate lambda values (log scale)
    lambda_values = np.logspace(np.log10(lambda_range[0]), np.log10(lambda_range[1]), num_points)
    
    frontier_data = []
    
    for i, lambda_val in enumerate(lambda_values):
        print(f"Processing point {i+1}/{num_points}: λ = {lambda_val:.2e}")
        
        # Run benchmark for this lambda (fewer simulations for efficiency)
        results = run_ac_benchmark(lambda_val, num_simulations=10, save_results=False)
        
        frontier_data.append({
            'lambda': lambda_val,
            'expected_shortfall': results['theoretical_expected_shortfall'],
            'variance': results['theoretical_variance'],
            'std_shortfall': np.sqrt(results['theoretical_variance']),
            'utility': results['theoretical_utility'],
            'simulated_mean_shortfall': results['mean_implementation_shortfall'],
            'simulated_std_shortfall': results['std_implementation_shortfall']
        })
    
    frontier_df = pd.DataFrame(frontier_data)
    
    if save_results:
        # Save efficient frontier
        frontier_file = os.path.join(config.RESULTS_DIR, 'ac_efficient_frontier.csv')
        frontier_df.to_csv(frontier_file, index=False)
        print(f"Efficient frontier saved to: {frontier_file}")
    
    return frontier_df

def main():
    """Main function to run the Almgren-Chriss benchmark."""
    print("="*60)
    print("ALMGREN-CHRISS BENCHMARK")
    print("="*60)
    
    # Run benchmark with default lambda
    print("\n1. Running benchmark with default lambda...")
    default_results = run_ac_benchmark()
    
    # Generate efficient frontier
    print("\n2. Generating efficient frontier...")
    frontier_df = generate_efficient_frontier(
        lambda_range=[1e-8, 1e-2],
        num_points=config.AC_NUM_POINTS
    )
    
    print("\n" + "="*60)
    print("BENCHMARK COMPLETED")
    print("="*60)
    print(f"Results saved to: {config.RESULTS_DIR}")
    print(f"Default lambda (λ = {config.LLAMBDA:.2e}) mean shortfall: ${default_results['mean_implementation_shortfall']:.2f}")
    print(f"Efficient frontier generated with {len(frontier_df)} points")
    
    # Display some key statistics
    print("\nEfficient Frontier Summary:")
    print(f"Min Expected Shortfall: ${frontier_df['expected_shortfall'].min():.2f}")
    print(f"Max Expected Shortfall: ${frontier_df['expected_shortfall'].max():.2f}")
    print(f"Min Std Shortfall: ${frontier_df['std_shortfall'].min():.2f}")
    print(f"Max Std Shortfall: ${frontier_df['std_shortfall'].max():.2f}")

if __name__ == "__main__":
    main() 