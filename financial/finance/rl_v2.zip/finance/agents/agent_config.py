"""
Agent Configuration Module
==========================

This module provides configuration classes for different RL agents,
making it easy to extend for new algorithms in Phase 2.
"""

from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class DDPGConfig:
    """Configuration for DDPG agent."""
    
    # Learning rates
    lr_actor: float = 1e-4
    lr_critic: float = 1e-3
    weight_decay: float = 0.0
    
    # Training parameters
    buffer_size: int = int(1e4)
    batch_size: int = 128
    gamma: float = 0.99
    tau: float = 1e-3
    
    # Network architecture
    actor_fc1_units: int = 24
    actor_fc2_units: int = 48
    critic_fcs1_units: int = 24
    critic_fc2_units: int = 48
    
    # Noise parameters (Ornstein-Uhlenbeck)
    ou_mu: float = 0.0
    ou_theta: float = 0.15
    ou_sigma: float = 0.2
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary for agent initialization."""
        return {
            'lr_actor': self.lr_actor,
            'lr_critic': self.lr_critic,
            'weight_decay': self.weight_decay,
            'buffer_size': self.buffer_size,
            'batch_size': self.batch_size,
            'gamma': self.gamma,
            'tau': self.tau,
            'fc1_units': self.actor_fc1_units,
            'fc2_units': self.actor_fc2_units,
            'fcs1_units': self.critic_fcs1_units,
            'fc2_units_critic': self.critic_fc2_units,
            'ou_mu': self.ou_mu,
            'ou_theta': self.ou_theta,
            'ou_sigma': self.ou_sigma
        }

@dataclass
class SACConfig:
    """Configuration for SAC agent (for Phase 2)."""
    
    # Learning rates
    lr_actor: float = 3e-4
    lr_critic: float = 3e-4
    lr_alpha: float = 3e-4
    
    # Training parameters
    buffer_size: int = int(1e6)
    batch_size: int = 256
    gamma: float = 0.99
    tau: float = 5e-3
    
    # Network architecture
    hidden_dim: int = 256
    
    # SAC specific
    alpha: float = 0.2
    automatic_entropy_tuning: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary for agent initialization."""
        return {
            'lr_actor': self.lr_actor,
            'lr_critic': self.lr_critic,
            'lr_alpha': self.lr_alpha,
            'buffer_size': self.buffer_size,
            'batch_size': self.batch_size,
            'gamma': self.gamma,
            'tau': self.tau,
            'hidden_dim': self.hidden_dim,
            'alpha': self.alpha,
            'automatic_entropy_tuning': self.automatic_entropy_tuning
        }

@dataclass
class TD3Config:
    """Configuration for TD3 agent (for Phase 2)."""
    
    # Learning rates
    lr_actor: float = 1e-3
    lr_critic: float = 1e-3
    weight_decay: float = 0.0
    
    # Training parameters
    buffer_size: int = int(1e6)
    batch_size: int = 256
    gamma: float = 0.99
    tau: float = 5e-3
    
    # Network architecture
    actor_fc1_units: int = 400
    actor_fc2_units: int = 300
    critic_fc1_units: int = 400
    critic_fc2_units: int = 300
    
    # TD3 specific
    policy_noise: float = 0.2
    noise_clip: float = 0.5
    policy_freq: int = 2
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary for agent initialization."""
        return {
            'lr_actor': self.lr_actor,
            'lr_critic': self.lr_critic,
            'weight_decay': self.weight_decay,
            'buffer_size': self.buffer_size,
            'batch_size': self.batch_size,
            'gamma': self.gamma,
            'tau': self.tau,
            'fc1_units': self.actor_fc1_units,
            'fc2_units': self.actor_fc2_units,
            'fcs1_units': self.critic_fc1_units,
            'fc2_units_critic': self.critic_fc2_units,
            'policy_noise': self.policy_noise,
            'noise_clip': self.noise_clip,
            'policy_freq': self.policy_freq
        }

# Agent configuration registry
AGENT_CONFIGS = {
    'ddpg': DDPGConfig,
    'sac': SACConfig,
    'td3': TD3Config
}

def get_agent_config(agent_type: str, **kwargs) -> Dict[str, Any]:
    """
    Get agent configuration with optional parameter overrides.
    
    Args:
        agent_type (str): Type of agent ('ddpg', 'sac', 'td3')
        **kwargs: Parameter overrides
        
    Returns:
        Dict[str, Any]: Agent configuration dictionary
        
    Example:
        # Get default DDPG config
        config = get_agent_config('ddpg')
        
        # Override specific parameters
        config = get_agent_config('ddpg', lr_actor=2e-4, batch_size=64)
    """
    if agent_type not in AGENT_CONFIGS:
        raise ValueError(f"Unknown agent type: {agent_type}. Available: {list(AGENT_CONFIGS.keys())}")
    
    config_class = AGENT_CONFIGS[agent_type]
    config = config_class(**kwargs)
    return config.to_dict() 