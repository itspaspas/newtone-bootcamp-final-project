"""
Agent Factory Module
===================

This module provides a factory pattern for creating different types of RL agents,
making it easy to add new algorithms in Phase 2 without modifying the main training script.
"""

from typing import Dict, Any, Type
from .ddpg_agent import Agent as DDPGAgent
from .agent_config import get_agent_config

# Agent registry - add new agents here in Phase 2
AGENT_REGISTRY = {
    'ddpg': DDPGAgent,
    # Phase 2 agents will be added here:
    # 'sac': SACAgent,
    # 'td3': TD3Agent,
    # 'ppo': PPOAgent,
}

def create_agent(agent_type: str, state_size: int, action_size: int, 
                 random_seed: int, config_overrides: Dict[str, Any] = None) -> Any:
    """
    Create an agent of the specified type.
    
    Args:
        agent_type (str): Type of agent to create ('ddpg', 'sac', 'td3', etc.)
        state_size (int): Dimension of the state space
        action_size (int): Dimension of the action space
        random_seed (int): Random seed for reproducibility
        config_overrides (Dict[str, Any], optional): Configuration overrides
        
    Returns:
        Agent instance
        
    Example:
        # Create DDPG agent with default config
        agent = create_agent('ddpg', state_size=8, action_size=1, random_seed=42)
        
        # Create DDPG agent with custom config
        overrides = {'lr_actor': 2e-4, 'batch_size': 64}
        agent = create_agent('ddpg', state_size=8, action_size=1, 
                           random_seed=42, config_overrides=overrides)
    """
    if agent_type not in AGENT_REGISTRY:
        available_agents = list(AGENT_REGISTRY.keys())
        raise ValueError(f"Unknown agent type: {agent_type}. Available agents: {available_agents}")
    
    # Get agent configuration
    config_overrides = config_overrides or {}
    agent_config = get_agent_config(agent_type, **config_overrides)
    
    # Get agent class and create instance
    agent_class = AGENT_REGISTRY[agent_type]
    agent = agent_class(
        state_size=state_size,
        action_size=action_size,
        random_seed=random_seed,
        **agent_config
    )
    
    return agent

def get_available_agents() -> list:
    """Get list of available agent types."""
    return list(AGENT_REGISTRY.keys())

def register_agent(agent_type: str, agent_class: Type) -> None:
    """
    Register a new agent type (for Phase 2 extensions).
    
    Args:
        agent_type (str): Name of the agent type
        agent_class (Type): Agent class
        
    Example:
        # In Phase 2, register new agents like this:
        register_agent('sac', SACAgent)
    """
    AGENT_REGISTRY[agent_type] = agent_class
    print(f"Registered new agent type: {agent_type}")

# Convenience function for creating agents with global config overrides
def create_agent_with_global_config(agent_type: str, state_size: int, action_size: int, 
                                   random_seed: int, global_config: Any) -> Any:
    """
    Create an agent using global configuration object.
    
    This function bridges the gap between the old config.py approach and the new
    flexible agent configuration system.
    
    Args:
        agent_type (str): Type of agent to create
        state_size (int): Dimension of the state space
        action_size (int): Dimension of the action space
        random_seed (int): Random seed for reproducibility
        global_config: Global configuration object (like config.py)
        
    Returns:
        Agent instance
    """
    # Map global config to agent-specific config
    config_mapping = {
        'ddpg': {
            'lr_actor': getattr(global_config, 'LR_ACTOR', 1e-4),
            'lr_critic': getattr(global_config, 'LR_CRITIC', 1e-3),
            'weight_decay': getattr(global_config, 'WEIGHT_DECAY', 0.0),
            'buffer_size': getattr(global_config, 'BUFFER_SIZE', int(1e4)),
            'batch_size': getattr(global_config, 'BATCH_SIZE', 128),
            'gamma': getattr(global_config, 'GAMMA', 0.99),
            'tau': getattr(global_config, 'TAU', 1e-3),
            'actor_fc1_units': getattr(global_config, 'ACTOR_FC1_UNITS', 24),
            'actor_fc2_units': getattr(global_config, 'ACTOR_FC2_UNITS', 48),
            'critic_fcs1_units': getattr(global_config, 'CRITIC_FCS1_UNITS', 24),
            'critic_fc2_units': getattr(global_config, 'CRITIC_FC2_UNITS', 48),
            'ou_mu': getattr(global_config, 'OU_MU', 0.0),
            'ou_theta': getattr(global_config, 'OU_THETA', 0.15),
            'ou_sigma': getattr(global_config, 'OU_SIGMA', 0.2),
        },
        # Add mappings for other agents in Phase 2
    }
    
    if agent_type not in config_mapping:
        # Fall back to default config if no mapping exists
        return create_agent(agent_type, state_size, action_size, random_seed)
    
    overrides = config_mapping[agent_type]
    return create_agent(agent_type, state_size, action_size, random_seed, overrides) 