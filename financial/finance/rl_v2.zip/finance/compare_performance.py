#!/usr/bin/env python3
"""
Performance Comparison Script
============================

This script compares the performance of trained RL agents against the
Almgren-Chriss analytical benchmark.

Usage:
    python compare_performance.py
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import sys

import config

def load_benchmark_results():
    """Load AC benchmark results from CSV files."""
    try:
        # Load AC benchmark summary
        ac_file = os.path.join(config.RESULTS_DIR, 'ac_benchmark_summary.csv')
        ac_df = pd.read_csv(ac_file)
        
        # Load efficient frontier
        frontier_file = os.path.join(config.RESULTS_DIR, 'ac_efficient_frontier.csv')
        frontier_df = pd.read_csv(frontier_file)
        
        return ac_df, frontier_df
    except FileNotFoundError as e:
        print(f"Error loading benchmark results: {e}")
        print("Please run main_ac_benchmark.py first to generate benchmark results.")
        return None, None

def load_rl_results():
    """Load RL agent results from CSV files."""
    try:
        # Load RL training summary
        rl_file = os.path.join(config.RESULTS_DIR, 'rl_training_summary.csv')
        rl_df = pd.read_csv(rl_file)
        
        # Load RL evaluation results
        eval_file = os.path.join(config.RESULTS_DIR, 'rl_evaluation_results.csv')
        eval_df = pd.read_csv(eval_file)
        
        return rl_df, eval_df
    except FileNotFoundError as e:
        print(f"Error loading RL results: {e}")
        print("Please run main_rl_agent.py first to generate RL results.")
        return None, None

def compare_performance(ac_df, rl_df):
    """
    Compare performance between AC benchmark and RL agent.
    
    Args:
        ac_df: DataFrame with AC benchmark results
        rl_df: DataFrame with RL training results
        
    Returns:
        dict: Comparison results
    """
    # Get the most recent results
    ac_latest = ac_df.iloc[-1]
    rl_latest = rl_df.iloc[-1]
    
    # Extract key metrics
    ac_shortfall = ac_latest['mean_implementation_shortfall']
    ac_std = ac_latest['std_implementation_shortfall']
    rl_shortfall = rl_latest['eval_mean_shortfall']
    rl_std = rl_latest['eval_std_shortfall']
    
    # Calculate performance metrics
    shortfall_difference = rl_shortfall - ac_shortfall
    performance_ratio = rl_shortfall / ac_shortfall
    
    comparison = {
        'ac_mean_shortfall': ac_shortfall,
        'ac_std_shortfall': ac_std,
        'rl_mean_shortfall': rl_shortfall,
        'rl_std_shortfall': rl_std,
        'shortfall_difference': shortfall_difference,
        'performance_ratio': performance_ratio,
        'rl_better': shortfall_difference < 0,
        'ac_theoretical_expected': ac_latest['theoretical_expected_shortfall'],
        'ac_theoretical_variance': ac_latest['theoretical_variance']
    }
    
    return comparison

def plot_performance_comparison(ac_df, rl_df, frontier_df, save_plots=True):
    """
    Create visualization comparing AC benchmark and RL agent performance.
    
    Args:
        ac_df: AC benchmark results
        rl_df: RL training results
        frontier_df: Efficient frontier data
        save_plots: Whether to save plots
    """
    if not config.PLOT_RESULTS:
        return
    
    # Create plots directory
    if save_plots:
        os.makedirs(config.PLOTS_DIR, exist_ok=True)
    
    # Create comparison plot
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # Plot 1: Implementation Shortfall Comparison
    ac_latest = ac_df.iloc[-1]
    rl_latest = rl_df.iloc[-1]
    
    methods = ['AC Benchmark', 'DDPG Agent']
    shortfalls = [ac_latest['mean_implementation_shortfall'], rl_latest['eval_mean_shortfall']]
    std_errors = [ac_latest['std_implementation_shortfall'], rl_latest['eval_std_shortfall']]
    
    colors = ['blue', 'red']
    bars = ax1.bar(methods, shortfalls, yerr=std_errors, capsize=5, color=colors, alpha=0.7)
    ax1.set_ylabel('Implementation Shortfall ($)')
    ax1.set_title('Performance Comparison: AC Benchmark vs DDPG Agent')
    ax1.grid(True, alpha=0.3)
    
    # Add value labels on bars
    for bar, shortfall, std in zip(bars, shortfalls, std_errors):
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2., height + std + 10000,
                f'${shortfall:,.0f}', ha='center', va='bottom', fontweight='bold')
    
    # Plot 2: Efficient Frontier with Agent Performance
    ax2.plot(frontier_df['std_shortfall'], frontier_df['expected_shortfall'], 
             'b-', linewidth=2, label='AC Efficient Frontier')
    
    # Add AC benchmark point
    ac_theoretical_std = np.sqrt(ac_latest['theoretical_variance'])
    ax2.plot(ac_theoretical_std, ac_latest['theoretical_expected_shortfall'], 
             'bo', markersize=8, label=f'AC Benchmark (λ={ac_latest["lambda"]:.2e})')
    
    # Add RL agent point
    ax2.plot(rl_latest['eval_std_shortfall'], rl_latest['eval_mean_shortfall'], 
             'ro', markersize=8, label='DDPG Agent')
    
    ax2.set_xlabel('Standard Deviation of Shortfall ($)')
    ax2.set_ylabel('Expected Shortfall ($)')
    ax2.set_title('Risk-Return Profile: Efficient Frontier vs DDPG Agent')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_plots:
        plot_file = os.path.join(config.PLOTS_DIR, 'performance_comparison.png')
        plt.savefig(plot_file, dpi=300, bbox_inches='tight')
        print(f"Performance comparison plot saved to: {plot_file}")
    
    plt.show()

def create_performance_table(comparison):
    """
    Create a formatted table showing performance comparison.
    
    Args:
        comparison: Dictionary with comparison results
    """
    print("\n" + "="*60)
    print("PERFORMANCE COMPARISON SUMMARY")
    print("="*60)
    
    print(f"{'Metric':<30} {'AC Benchmark':<15} {'DDPG Agent':<15}")
    print("-" * 60)
    print(f"{'Mean Shortfall ($)':<30} {comparison['ac_mean_shortfall']:>14,.0f} {comparison['rl_mean_shortfall']:>14,.0f}")
    print(f"{'Std Shortfall ($)':<30} {comparison['ac_std_shortfall']:>14,.0f} {comparison['rl_std_shortfall']:>14,.0f}")
    print(f"{'Theoretical Expected ($)':<30} {comparison['ac_theoretical_expected']:>14,.0f} {'N/A':<15}")
    print(f"{'Theoretical Variance':<30} {comparison['ac_theoretical_variance']:>14,.0f} {'N/A':<15}")
    
    print("\n" + "="*60)
    print("COMPARISON RESULTS")
    print("="*60)
    
    print(f"Shortfall Difference: ${comparison['shortfall_difference']:+,.0f}")
    print(f"Performance Ratio: {comparison['performance_ratio']:.3f}")
    
    if comparison['rl_better']:
        print("✓ DDPG Agent OUTPERFORMS AC Benchmark")
    else:
        print("✗ DDPG Agent UNDERPERFORMS AC Benchmark")
    
    performance_gap = abs(comparison['shortfall_difference'] / comparison['ac_mean_shortfall'] * 100)
    print(f"Performance Gap: {performance_gap:.1f}%")

def save_comparison_results(comparison):
    """Save comparison results to CSV."""
    os.makedirs(config.RESULTS_DIR, exist_ok=True)
    
    comparison_file = os.path.join(config.RESULTS_DIR, 'performance_comparison.csv')
    comparison_df = pd.DataFrame([comparison])
    comparison_df.to_csv(comparison_file, index=False)
    print(f"Comparison results saved to: {comparison_file}")

def main():
    """Main function to run performance comparison."""
    print("="*60)
    print("PERFORMANCE COMPARISON: AC BENCHMARK vs DDPG AGENT")
    print("="*60)
    
    # Load results
    print("Loading benchmark results...")
    ac_df, frontier_df = load_benchmark_results()
    if ac_df is None or frontier_df is None:
        return
    
    print("Loading RL agent results...")
    rl_df, eval_df = load_rl_results()
    if rl_df is None or eval_df is None:
        return
    
    # Perform comparison
    print("Comparing performance...")
    comparison = compare_performance(ac_df, rl_df)
    
    # Display results
    create_performance_table(comparison)
    
    # Create visualizations
    print("\nGenerating comparison plots...")
    plot_performance_comparison(ac_df, rl_df, frontier_df)
    
    # Save results
    save_comparison_results(comparison)
    
    print("\n" + "="*60)
    print("COMPARISON COMPLETED")
    print("="*60)
    
    # Provide recommendations
    print("\nRecommendations:")
    if comparison['rl_better']:
        print("• The DDPG agent has successfully learned a strategy that outperforms the AC benchmark!")
        print("• Consider running longer training to potentially improve performance further.")
    else:
        print("• The DDPG agent is not yet matching the AC benchmark performance.")
        print("• Consider hyperparameter tuning or longer training.")
        print("• The AC benchmark represents the theoretical optimum under linear assumptions.")
    
    print(f"• Results saved to: {config.RESULTS_DIR}")

if __name__ == "__main__":
    main() 