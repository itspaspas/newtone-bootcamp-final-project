#!/usr/bin/env python3
"""
RL Agent Training Script
=======================

This script trains and evaluates Deep Reinforcement Learning agents for the
optimal liquidation problem. It supports DDPG initially, with extensibility
for other algorithms.

Usage:
    python main_rl_agent.py [--agent ddpg] [--episodes 1000] [--eval-episodes 100]
"""

import numpy as np
import pandas as pd
import os
import sys
import argparse
import torch
from datetime import datetime
from collections import deque
import matplotlib.pyplot as plt

# Import project modules
from envs.base_env import MarketEnvironment
from agents.agent_factory import create_agent_with_global_config, get_available_agents
import utils
import config

def train_ddpg_agent(env, agent, num_episodes=config.NUM_EPISODES, save_models=True):
    """
    Train a DDPG agent on the given environment.
    
    Args:
        env: MarketEnvironment instance
        agent: DDPG Agent instance
        num_episodes (int): Number of training episodes
        save_models (bool): Whether to save model checkpoints
        
    Returns:
        dict: Training results and statistics
    """
    print(f"Training DDPG Agent for {num_episodes} episodes")
    print("-" * 50)
    
    # Training tracking
    scores = []
    scores_window = deque(maxlen=100)
    episode_shortfalls = []
    episode_rewards = []
    
    # Create model save directory
    if save_models:
        model_dir = os.path.join(config.MODEL_SAVE_PATH, 'ddpg')
        os.makedirs(model_dir, exist_ok=True)
    
    for episode in range(1, num_episodes + 1):
        # Reset environment and agent
        state = env.reset(seed=episode)
        env.start_transactions()
        agent.reset()
        
        episode_reward = 0
        episode_steps = 0
        
        while True:
            # Agent selects action
            action = agent.act(state)
            
            # Environment step
            next_state, reward, done, info = env.step(action)
            
            # Agent learns from experience
            agent.step(state, action, reward, next_state, done)
            
            # Update tracking variables
            state = next_state
            episode_reward += reward.item() if hasattr(reward, 'item') else reward
            episode_steps += 1
            
            if done:
                # Record episode results
                if hasattr(info, 'implementation_shortfall'):
                    episode_shortfalls.append(info.implementation_shortfall)
                else:
                    episode_shortfalls.append(0)  # Fallback
                
                episode_rewards.append(episode_reward)
                scores.append(episode_reward)
                scores_window.append(episode_reward)
                break
        
        # Logging
        if episode % config.LOG_INTERVAL == 0:
            avg_score = np.mean(scores_window)
            avg_shortfall = np.mean(episode_shortfalls[-config.LOG_INTERVAL:]) if episode_shortfalls else 0
            
            print(f'Episode {episode:4d}\t'
                  f'Average Score: {avg_score:.2f}\t'
                  f'Average Shortfall: ${avg_shortfall:.2f}\t'
                  f'Steps: {episode_steps}')
        
        # Save model checkpoints
        if save_models and episode % config.SAVE_INTERVAL == 0:
            checkpoint_path = os.path.join(model_dir, f'checkpoint_episode_{episode}.pth')
            torch.save({
                'episode': episode,
                'actor_state_dict': agent.actor_local.state_dict(),
                'critic_state_dict': agent.critic_local.state_dict(),
                'actor_optimizer_state_dict': agent.actor_optimizer.state_dict(),
                'critic_optimizer_state_dict': agent.critic_optimizer.state_dict(),
                'scores': scores,
                'episode_shortfalls': episode_shortfalls
            }, checkpoint_path)
            print(f'Model checkpoint saved: {checkpoint_path}')
    
    # Save final model
    if save_models:
        final_model_path = os.path.join(model_dir, 'final_model.pth')
        torch.save({
            'episode': num_episodes,
            'actor_state_dict': agent.actor_local.state_dict(),
            'critic_state_dict': agent.critic_local.state_dict(),
            'actor_optimizer_state_dict': agent.actor_optimizer.state_dict(),
            'critic_optimizer_state_dict': agent.critic_optimizer.state_dict(),
            'scores': scores,
            'episode_shortfalls': episode_shortfalls
        }, final_model_path)
        print(f'Final model saved: {final_model_path}')
    
    # Calculate final statistics
    final_avg_score = np.mean(scores[-100:]) if len(scores) >= 100 else np.mean(scores)
    final_avg_shortfall = np.mean(episode_shortfalls[-100:]) if len(episode_shortfalls) >= 100 else np.mean(episode_shortfalls)
    
    training_results = {
        'algorithm': 'DDPG',
        'num_episodes': num_episodes,
        'final_avg_score': final_avg_score,
        'final_avg_shortfall': final_avg_shortfall,
        'all_scores': scores,
        'all_shortfalls': episode_shortfalls,
        'all_rewards': episode_rewards,
        'timestamp': datetime.now().isoformat()
    }
    
    print(f"\nTraining completed!")
    print(f"Final average score (last 100 episodes): {final_avg_score:.2f}")
    print(f"Final average shortfall (last 100 episodes): ${final_avg_shortfall:.2f}")
    
    return training_results

def evaluate_agent(env, agent, num_episodes=100, model_path=None):
    """
    Evaluate a trained agent on the environment.
    
    Args:
        env: MarketEnvironment instance
        agent: Agent instance
        num_episodes (int): Number of evaluation episodes
        model_path (str): Path to saved model (if None, uses current agent)
        
    Returns:
        dict: Evaluation results
    """
    print(f"Evaluating agent for {num_episodes} episodes")
    print("-" * 50)
    
    # Load model if path provided
    if model_path and os.path.exists(model_path):
        checkpoint = torch.load(model_path)
        agent.actor_local.load_state_dict(checkpoint['actor_state_dict'])
        agent.critic_local.load_state_dict(checkpoint['critic_state_dict'])
        print(f"Loaded model from: {model_path}")
    
    # Evaluation tracking
    eval_shortfalls = []
    eval_rewards = []
    eval_captures = []
    
    for episode in range(num_episodes):
        # Reset environment
        state = env.reset(seed=episode + 10000)  # Different seeds for evaluation
        env.start_transactions()
        
        episode_reward = 0
        
        while True:
            # Agent selects action (no noise during evaluation)
            action = agent.act(state, add_noise=False)
            
            # Environment step
            next_state, reward, done, info = env.step(action)
            
            # Update tracking
            state = next_state
            episode_reward += reward.item() if hasattr(reward, 'item') else reward
            
            if done:
                # Record episode results
                if hasattr(info, 'implementation_shortfall'):
                    eval_shortfalls.append(info.implementation_shortfall)
                else:
                    eval_shortfalls.append(0)
                
                eval_rewards.append(episode_reward)
                eval_captures.append(env.totalCapture)
                break
        
        # Progress reporting
        if (episode + 1) % 20 == 0:
            avg_shortfall = np.mean(eval_shortfalls)
            print(f'Evaluation episode {episode + 1:3d}/{num_episodes}\t'
                  f'Average Shortfall: ${avg_shortfall:.2f}')
    
    # Calculate evaluation statistics
    eval_results = {
        'num_episodes': num_episodes,
        'mean_shortfall': np.mean(eval_shortfalls),
        'std_shortfall': np.std(eval_shortfalls),
        'mean_reward': np.mean(eval_rewards),
        'std_reward': np.std(eval_rewards),
        'mean_capture': np.mean(eval_captures),
        'all_shortfalls': eval_shortfalls,
        'all_rewards': eval_rewards,
        'all_captures': eval_captures,
        'timestamp': datetime.now().isoformat()
    }
    
    print(f"\nEvaluation completed!")
    print(f"Mean Implementation Shortfall: ${eval_results['mean_shortfall']:.2f} ± ${eval_results['std_shortfall']:.2f}")
    print(f"Mean Episode Reward: {eval_results['mean_reward']:.2f} ± {eval_results['std_reward']:.2f}")
    print(f"Mean Total Capture: ${eval_results['mean_capture']:.2f}")
    
    return eval_results

def save_training_results(training_results, eval_results=None):
    """
    Save training and evaluation results to CSV files.
    
    Args:
        training_results (dict): Results from training
        eval_results (dict): Results from evaluation (optional)
    """
    # Create results directory
    os.makedirs(config.RESULTS_DIR, exist_ok=True)
    
    # Save training summary
    training_file = os.path.join(config.RESULTS_DIR, 'rl_training_summary.csv')
    training_data = {
        'algorithm': [training_results['algorithm']],
        'num_episodes': [training_results['num_episodes']],
        'final_avg_score': [training_results['final_avg_score']],
        'final_avg_shortfall': [training_results['final_avg_shortfall']],
        'timestamp': [training_results['timestamp']]
    }
    
    if eval_results:
        training_data.update({
            'eval_episodes': [eval_results['num_episodes']],
            'eval_mean_shortfall': [eval_results['mean_shortfall']],
            'eval_std_shortfall': [eval_results['std_shortfall']],
            'eval_mean_reward': [eval_results['mean_reward']]
        })
    
    training_df = pd.DataFrame(training_data)
    
    # Append to existing file or create new one
    if os.path.exists(training_file):
        existing_df = pd.read_csv(training_file)
        training_df = pd.concat([existing_df, training_df], ignore_index=True)
    
    training_df.to_csv(training_file, index=False)
    print(f"Training summary saved to: {training_file}")
    
    # Save detailed episode results
    episodes_file = os.path.join(config.RESULTS_DIR, 'rl_episode_results.csv')
    episodes_df = pd.DataFrame({
        'episode': range(1, len(training_results['all_scores']) + 1),
        'score': training_results['all_scores'],
        'shortfall': training_results['all_shortfalls'],
        'reward': training_results['all_rewards']
    })
    episodes_df.to_csv(episodes_file, index=False)
    print(f"Episode results saved to: {episodes_file}")
    
    # Save evaluation results if available
    if eval_results:
        eval_file = os.path.join(config.RESULTS_DIR, 'rl_evaluation_results.csv')
        eval_df = pd.DataFrame({
            'episode': range(1, len(eval_results['all_shortfalls']) + 1),
            'shortfall': eval_results['all_shortfalls'],
            'reward': eval_results['all_rewards'],
            'capture': eval_results['all_captures']
        })
        eval_df.to_csv(eval_file, index=False)
        print(f"Evaluation results saved to: {eval_file}")

def plot_training_progress(training_results, save_plots=True):
    """
    Plot training progress and save figures.
    
    Args:
        training_results (dict): Results from training
        save_plots (bool): Whether to save plots to files
    """
    if not config.PLOT_RESULTS:
        return
    
    # Create plots directory
    if save_plots:
        os.makedirs(config.PLOTS_DIR, exist_ok=True)
    
    # Plot 1: Training scores over episodes
    plt.figure(figsize=(12, 4))
    
    plt.subplot(1, 2, 1)
    episodes = range(1, len(training_results['all_scores']) + 1)
    plt.plot(episodes, training_results['all_scores'], alpha=0.6, label='Episode Score')
    
    # Add moving average
    window_size = 100
    if len(training_results['all_scores']) >= window_size:
        moving_avg = pd.Series(training_results['all_scores']).rolling(window=window_size).mean()
        plt.plot(episodes, moving_avg, 'r-', linewidth=2, label=f'{window_size}-Episode Moving Average')
    
    plt.xlabel('Episode')
    plt.ylabel('Score')
    plt.title('Training Scores Over Episodes')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Plot 2: Implementation shortfall over episodes
    plt.subplot(1, 2, 2)
    plt.plot(episodes, training_results['all_shortfalls'], alpha=0.6, label='Implementation Shortfall')
    
    # Add moving average
    if len(training_results['all_shortfalls']) >= window_size:
        moving_avg = pd.Series(training_results['all_shortfalls']).rolling(window=window_size).mean()
        plt.plot(episodes, moving_avg, 'r-', linewidth=2, label=f'{window_size}-Episode Moving Average')
    
    plt.xlabel('Episode')
    plt.ylabel('Implementation Shortfall ($)')
    plt.title('Implementation Shortfall Over Episodes')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_plots:
        plot_file = os.path.join(config.PLOTS_DIR, 'training_progress.png')
        plt.savefig(plot_file, dpi=300, bbox_inches='tight')
        print(f"Training progress plot saved to: {plot_file}")
    
    plt.show()

def main():
    """Main function to train and evaluate RL agents."""
    parser = argparse.ArgumentParser(description='Train and evaluate RL agents for optimal liquidation')
    parser.add_argument('--agent', type=str, default='ddpg', choices=get_available_agents(), 
                        help='RL algorithm to use')
    parser.add_argument('--episodes', type=int, default=config.NUM_EPISODES,
                        help='Number of training episodes')
    parser.add_argument('--eval-episodes', type=int, default=100,
                        help='Number of evaluation episodes')
    parser.add_argument('--no-train', action='store_true',
                        help='Skip training and only evaluate')
    parser.add_argument('--model-path', type=str, default=None,
                        help='Path to saved model for evaluation')
    
    args = parser.parse_args()
    
    print("="*60)
    print("RL AGENT TRAINING AND EVALUATION")
    print("="*60)
    print(f"Algorithm: {args.agent.upper()}")
    print(f"Training episodes: {args.episodes}")
    print(f"Evaluation episodes: {args.eval_episodes}")
    print()
    
    # Initialize environment
    env = MarketEnvironment(randomSeed=config.RANDOM_SEED)
    
    # Initialize agent using factory pattern
    available_agents = get_available_agents()
    if args.agent not in available_agents:
        raise ValueError(f"Unknown agent type: {args.agent}. Available agents: {available_agents}")
    
    agent = create_agent_with_global_config(
        agent_type=args.agent,
        state_size=env.observation_space_dimension(),
        action_size=env.action_space_dimension(),
        random_seed=config.RANDOM_SEED,
        global_config=config
    )
    
    training_results = None
    eval_results = None
    
    # Training phase
    if not args.no_train:
        print("Starting training phase...")
        training_results = train_ddpg_agent(env, agent, args.episodes)
        
        # Plot training progress
        plot_training_progress(training_results)
    
    # Evaluation phase
    print("\nStarting evaluation phase...")
    eval_results = evaluate_agent(env, agent, args.eval_episodes, args.model_path)
    
    # Save results
    if training_results:
        save_training_results(training_results, eval_results)
    
    print("\n" + "="*60)
    print("TRAINING AND EVALUATION COMPLETED")
    print("="*60)
    
    if eval_results:
        print(f"Final Agent Performance:")
        print(f"Mean Implementation Shortfall: ${eval_results['mean_shortfall']:.2f}")
        print(f"Standard Deviation: ${eval_results['std_shortfall']:.2f}")
        print(f"Results saved to: {config.RESULTS_DIR}")

if __name__ == "__main__":
    main() 